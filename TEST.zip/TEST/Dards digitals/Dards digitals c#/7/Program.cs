﻿using System;

public class Darts
{
    private static readonly int[,] diana =
    {
        {0, 0, 0, 0, 0, 0, 0, 0, 0 },
        {0, 1, 1, 1, 1, 1, 1, 1, 0 },
        {0, 1, 2, 2, 2, 2, 2, 1, 0 },
        {0, 1, 2, 5, 5, 5, 2, 1, 0 },
        {0, 1, 2, 5, 10, 5, 2, 1, 0 },
        {0, 1, 2, 5, 5, 5, 2, 1, 0 },
        {0, 1, 2, 2, 2, 2, 2, 1, 0 },
        {0, 1, 1, 1, 1, 1, 1, 1, 0 },
        {0, 0, 0, 0, 0, 0, 0, 0, 0 },
    };

    public int GetScore(int x, int y)
    {
        if (x < 0 || x >= diana.GetLength(0) || y < 0 || y >= diana.GetLength(1))
        {
            throw new ArgumentOutOfRangeException("Les coordenades han de ser dins de la diana.");
        }
        return diana[x, y];
    }

    public string PlayGame(Random random, int targetScore = 50)
    {
        int totalScore1 = 0;
        int totalScore2 = 0;

        while (totalScore1 < targetScore && totalScore2 < targetScore)
        {
            int x1 = random.Next(9);
            int y1 = random.Next(9);
            int x2 = random.Next(9);
            int y2 = random.Next(9);

            int score1 = GetScore(x1, y1);
            int score2 = GetScore(x2, y2);

            totalScore1 += score1;
            totalScore2 += score2;
        }

        return totalScore1 > totalScore2 ? "Jugador 1" : "Jugador 2";
    }
}