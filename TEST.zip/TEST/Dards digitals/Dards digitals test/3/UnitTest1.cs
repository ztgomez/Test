using System;
using Xunit;

public class DartsGameTests
{
    [Fact]
    public void 1() //retorni el valor correcte per coordenades vàlides
    {
        var game = new DartsGame();
        Assert.Equal(10, game.GetScore(4, 4));
        Assert.Equal(5, game.GetScore(3, 3));
        Assert.Equal(0, game.GetScore(0, 0));
    }

    [Fact]
    public void 2() //Verifica que es llança una excepció per coordenades fora de la matriu
    {
        var game = new DartsGame();
        Assert.Throws<ArgumentOutOfRangeException>(() => game.GetScore(-1, 4));
        Assert.Throws<ArgumentOutOfRangeException>(() => game.GetScore(9, 4));
        Assert.Throws<ArgumentOutOfRangeException>(() => game.GetScore(4, 9));
    }

    [Fact]
    public void 3() //Similar a l'anterior, però assegura que guanyi el jugador 2.
    {
        var game = new DartsGame();
        var random = new Random(2);
        var resultat = game.PlayGame(random, targetScore: 50);
        Assert.Equal("Jugador 2", resultat);
    }

    [Fact]
    public void 4() //Prova amb un objectiu diferent (30 punts) per assegurar que el joc és flexible
    {
        var game = new DartsGame();
        var random = new Random(3);
        var resultat = game.PlayGame(random, targetScore: 30);
        Assert.NotNull(resultat);
    }
}
