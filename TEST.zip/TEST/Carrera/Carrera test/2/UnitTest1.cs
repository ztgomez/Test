using Xunit;

public class CarreraTests
{
    [Fact]
    public void Guanyador_MatriuSimple()
    {
        int[,] carrera = {
            { 1, 4, 5, 3 },
            { 2, 6, 8, 1 },
            { 3, 2, 4, 6 },
            { 4, 7, 3, 9 }
        };

        int resultat = Program.Guanyador(carrera);
        Assert.Equal(4, resultat);
    }

    [Fact]
    public void Guanyador_Matriubuida()
    {
        int[,] carrera = new int[0, 0];
        int resultat = Program.Guanyador(carrera);
        Assert.Equal(-1, resultat);
    }

    [Fact]
    public void Guanyador_1corredor()
    {
        int[,] carrera = {
            { 1, 3, 5, 7 }
        };

        int resultat = Program.Guanyador(carrera);
        Assert.Equal(1, resultat);
    }

    [Fact]
    public void Guanyador_Valorsmaximin()
    {
        int[,] carrera = {
            { 1, int.MaxValue, int.MinValue },
            { 2, int.MinValue, int.MaxValue }
        };

        int resultat = Program.Guanyador(carrera);
        Assert.Equal(1, resultat);
    }

    [Fact]
    public void Guanyador_Valorsnegatius()
    {
        int[,] carrera = {
            { 1, -5, -10, -3 },
            { 2, -2, -8, -1 },
            { 3, -7, -9, -6 }
        };

        int resultat = Program.Guanyador(carrera);
        Assert.Equal(2, resultat);
    }

}
