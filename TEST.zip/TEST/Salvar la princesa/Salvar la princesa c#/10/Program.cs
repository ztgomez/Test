﻿class SalvemLaPrincesa
{
    static void Main()
    {
        string[] armes = {
            "Casc", "Escut", "Espasa", "Armadura", "Llança", "Escut", "Escut", "Espasa", "Llança"
        };

        var resultat = CalcularForces(armes);

        Console.WriteLine("Es pot enviar:");
        Console.WriteLine($"  Pagesos: {resultat.pagesos}");
        Console.WriteLine($"  Soldats: {resultat.soldats}");
        Console.WriteLine($"  Cavallers: {resultat.cavallers}");
    }

    public static (int cavallers, int soldats, int pagesos) CalcularForces(string[] armes)
    {
        Dictionary<string, int> equips = new Dictionary<string, int>
        {
            { "Casc", 0 },
            { "Escut", 0 },
            { "Espasa", 0 },
            { "Armadura", 0 },
            { "Llança", 0 }
        };

        foreach (var item in armes)
        {
            if (equips.ContainsKey(item))
            {
                equips[item]++;
            }
        }

        int cavallers = Math.Min(Math.Min(equips["Casc"], equips["Escut"]),
                                  Math.Min(equips["Armadura"], equips["Llança"]));

        equips["Casc"] -= cavallers;
        equips["Escut"] -= cavallers;
        equips["Armadura"] -= cavallers;
        equips["Llança"] -= cavallers;

        int soldats = Math.Min(Math.Min(equips["Casc"], equips["Escut"]), equips["Espasa"]);

        equips["Casc"] -= soldats;
        equips["Escut"] -= soldats;
        equips["Espasa"] -= soldats;

        int pagesos = equips["Llança"];

        return (cavallers, soldats, pagesos);
    }
}
