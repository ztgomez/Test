using Xunit;

public class SalvemLaPrincesaTests
{
    public void Test_Calcul_Equipaments_Basics()
    {
        string[] armes = { "Casc", "Escut", "Espasa", "Armadura", "Llança" };

        var resultat = SalvemLaPrincesa.CalcularForces(armes);

        Assert.Equal(1, resultat.cavallers);
        Assert.Equal(0, resultat.soldats);
        Assert.Equal(0, resultat.pagesos);
    }

    [Fact]
    public void Test_Llista_Buida()
    {
        string[] armes = { };

        var resultat = SalvemLaPrincesa.CalcularForces(armes);

        Assert.Equal(0, resultat.cavallers);
        Assert.Equal(0, resultat.soldats);
        Assert.Equal(0, resultat.pagesos);
    }

    [Fact]
    public void Test_Multiples_Equipaments()
    {
        string[] armes = { "Casc", "Escut", "Espasa", "Escut", "Llança", "Armadura", "Llança", "Casc", "Escut", "Espasa" };

        var resultat = SalvemLaPrincesa.CalcularForces(armes);

        Assert.Equal(1, resultat.cavallers);
        Assert.Equal(1, resultat.soldats);
        Assert.Equal(1, resultat.pagesos);
    }

    [Fact]
    public void Test_Casos_Extrems()
    {
        string[] armes = { "Casc", "Casc", "Casc", "Escut", "Escut", "Espasa", "Armadura", "Llança", "Llança", "Llança" };

        var resultat = SalvemLaPrincesa.CalcularForces(armes);

        Assert.Equal(2, resultat.cavallers);
        Assert.Equal(0, resultat.soldats);
        Assert.Equal(1, resultat.pagesos);
    }
}
